
# MediaPipe Landmark Similarity Evaluation

Dieses Projekt implementiert:
- Speicherung von MediaPipe-Landmarks
- Feature-Extraktion (Embeddings)
- Similarity Search
- Evaluation mit mAP und Precision@K

## Struktur
- schema.sql              → SQLite Schema
- feature_extraction.py   → Normalisierung & Embeddings
- similarity.py           → Similarity Search
- evaluation.py           → mAP / Precision@K
- example_pipeline.py     → End-to-End Beispiel

## Voraussetzung
- Python 3.9+
- numpy

## Ablauf
1. SQLite DB mit schema.sql erstellen
2. Landmarks + Labels einfügen
3. Embeddings berechnen
4. Evaluation starten
