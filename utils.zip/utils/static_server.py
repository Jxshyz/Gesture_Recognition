# utils/static_server.py
from __future__ import annotations
from .ws_server import start_server_background

# nur alias – falls ihr es getrennt halten wollt
